            _______ _                ___    ___                  
            (_______|_)              / __)  / __)                 
            _   ___ _  ____ _____ _| |__ _| |__ _____            
            | | (_  | |/ ___|____ (_   __|_   __) ___ |           
            | |___) | | |   / ___ | | |    | |  | ____|           
            \_____/|_|_|   \_____| |_|    |_|  |_____)           
                                                                
         _______                                    _             
        (_______)                               _  (_)            
        _____   ____   ____  ____ _   _ ____ _| |_ _  ___  ____  
        |  ___) |  _ \ / ___)/ ___) | | |  _ (_   _) |/ _ \|  _ \ 
        | |_____| | | ( (___| |   | |_| | |_| || |_| | |_| | | | |
        |_______)_| |_|\____)_|    \__  |  __/  \__)_|\___/|_| |_|
                                (____/|_|                       

Giraffe Encryption is a package for encrypting and decrypting secrets in a fun and quirky way. It makes use of RSA public-private key encryption.

## giraffe-keygen

* Generate RSA keypair in .giraffe directory



